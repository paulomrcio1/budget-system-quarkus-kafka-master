CREATE TABLE balances (
    id varchar not null primary key,
    account_id varchar not null,
    value decimal not null
);